function fatScroll() {
    var scroll = $('.fat-scroll');
    self.itemHeight = scroll.find('li').first().outerHeight();
    self.scrollHeight = scroll.height();
    self.inactiveClass = 'fat-scroll-bounce';
    scroll.on('scroll', function() {
        var scrollOffset = $(this).scrollTop();
        var elemScrollPast = Math.floor(scrollOffset/self.itemHeight);
        var elemScrollActive = Math.ceil((scrollOffset+600)/self.itemHeight);
        $(this).find('li:lt(' + elemScrollActive + ')').removeClass(self.inactiveClass);
        $(this).find('li:lt(' + elemScrollPast + ')').addClass(self.inactiveClass);
        $(this).find('li:gt(' + (elemScrollActive-1) + ')').addClass(self.inactiveClass);
    });
}

jQuery.fn.extend({
    fatScroll : function(options) {
        if (!options) { options = {}; }
        this.each(function() {
            var self = {};
            self.itemHeight = $(this).find('li').first().outerHeight();
            self.scrollHeight = $(this).find('ul').outerHeight();
            if (!options.style) {
                options.style = 'shrink';
            }
            self.inactiveClass = 'fat-scroll-' + options.style;

            $(this).addClass(self.inactiveClass);

            $(this).find('.fat-scroll-list').on('scroll', function() {
                var scrollOffset = $(this).scrollTop();
                var elemScrollPast = Math.floor(scrollOffset/self.itemHeight);
                var elemScrollActive = Math.ceil((scrollOffset + self.scrollHeight)/self.itemHeight);
                $(this).find('li:lt(' + elemScrollActive + ')').removeClass('fat-scroll-past').removeClass('fat-scroll-future');
                $(this).find('li:lt(' + elemScrollPast + ')').addClass('fat-scroll-past').removeClass('fat-scroll-future');
                $(this).find('li:gt(' + (elemScrollActive-1) + ')').removeClass('fat-scroll-past').addClass('fat-scroll-future');
            });

        });
    }
});