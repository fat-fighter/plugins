//Flow Direction
//Autoplay
//Scroll to Change
//Image align
//Padding
//Margin
//Arrows
//Add Navigation Option
//Add Controls Option
//Drag Controls

Array.prototype.getValueForLess = function(value) {
    var list = Object(this).sort(function(a, b){return a[0] < b[0]});
    var len = list.length;
    for (var i = 0; i < len; i++) {
        if (list[i][0] <= value) { return list[i][1]; }
    }
    return 1;
};

jQuery.fn.extend({
    fatCarousel : function(options) {
        if (!options) { options = {}; }

        $(this).each(function() {
            var self = $(this);

            var carousel;
            var carouselContainer;
            var carouselNav;

            /* -------------------- INITIALIZE -------------------- */

            self.initialize = function() {
                self.images = options['imageArray'] ? options['imageArray'] : [];
                self.itemsOnScreen = options['itemsOnScreen'] ? options['itemsOnScreen'] : 1;
                self.activeItem = options['startSlide'] ? options['startSlide'] : 1;

                carousel = self;
                carouselContainer = carousel.find('.fat-carousel-container');

                self.addImages();
                self.setPreferences();
                self.removeNavigation();
                self.removeControls();
                self.addNavigation();
                self.addControls();
                self.addCarouselScrollStop();
                self.addResizeControl();

                self.scrollToSlide(1, self.activeItem - 1);
            };

            self.slideAnimation = setInterval(function() { self.scrollToSlide(600, null); }, 5000);

            self.addImages = function() {
                for (var i = 0; i < self.images.length; i++) {
                    var imageHTML = "<div class='fat-carousel-item'>";
                    imageHTML += "<img src='" + self.images[i] + "'>";
                    imageHTML += "</div>";
                    carouselContainer.append(imageHTML);
                }

                var index = 1;
                carouselContainer.find('.fat-carousel-item').each(function() {
                    $(this).attr('data-order', index++);
                });
                self.contentLength = index-1;
                carouselContainer.find('.fat-carousel-item:first-of-type').addClass('fat-carousel-active');
            };

            /* -------------------- NAVIGATION -------------------- */

            self.addNavigation = function () {
                carousel.append("<div class='fat-carousel-nav'></div>");
                carouselNav = carousel.find('.fat-carousel-nav');
                var navLength = Math.ceil(self.contentLength / self.itemsOnScreen);
                for (var i = 0; i < navLength; i++) {
                    carouselNav.append("<div><span data-trigger='" + i + "'></span>");
                }
                self.setNavigationActive();

                carousel.find('.fat-carousel-nav span').on('click', function() {
                    self.scrollToSlide(600, this);
                    carousel.find('.fat-carousel-nav span').removeClass('fat-carousel-nav-active');
                    $(this).addClass('fat-carousel-nav-active');
                });
            };

            self.removeNavigation = function() {
                carousel.find('.fat-carousel-nav').remove();
            };

            self.setNavigationActive = function() {
                var index = self.activeItem - 1;
                var navIndex = Math.floor(index / self.itemsOnScreen);
                if (index == self.contentLength - self.itemsOnScreen) {
                    if (index / self.itemsOnScreen != navIndex) {
                        navIndex += 1;
                    }
                }
                carouselNav.find('span').removeClass('fat-carousel-nav-active');
                carouselNav.find('span[data-trigger=' + navIndex + ']').addClass('fat-carousel-nav-active');
            };

            /* -------------------- CONTROLS -------------------- */

            self.addControls = function() {
                carousel.append("<div class='fat-carousel-controls'></div>");
                carousel.find('.fat-carousel-controls')
                    .append("<div><input type='button' value='prev' data-toggle='left'></div>")
                    .append("<div><input type='button' value='next' data-toggle='right'></div>");

                carousel.find('.fat-carousel-controls div input[type=button]').on('click', function() {
                    if ($(this).attr('data-toggle') == "right") {
                        self.scrollToSlide(600, null, 1);
                    }
                    else {
                        self.scrollToSlide(600, null, -1);
                    }
                });
            };

            self.removeControls = function() {
                carousel.find('.fat-carousel-controls').remove();
            };

            /* -------------------- SET PREFERENCES -------------------- */

            self.applyPreferences = function() {
                self.carouselWidth = carousel.width();
                self.itemWidth = Math.floor(self.carouselWidth / self.itemsOnScreen);
                carouselContainer.find('.fat-carousel-item').css({
                    minWidth: (self.itemWidth - 20) + 'px'
                });

                self.removeNavigation();
                self.addNavigation();

                self.removeControls();
                self.addControls();
            };

            self.setPreferences = function() {
                self.carouselWidth = carousel.width();
                if (typeof options['itemsOnScreen'] == "object") {
                    self.itemsOnScreen = options['itemsOnScreen'].getValueForLess($(window).outerWidth());
                }
                else if (typeof options['itemsOnScreen'] == "number") {
                    self.itemsOnScreen = options['itemsOnScreen'];
                }
                else {
                    self.itemsOnScreen = 1;
                }
                self.itemWidth = Math.floor(self.carouselWidth / self.itemsOnScreen);
                self.applyPreferences();
            };

            /* -------------------- ACTIONS -------------------- */

            self.scrollToSlide = function(time, trigger, order) {
                var index = 0;
                if (!time) { time = 600; }
                if (typeof(trigger) == "undefined" || trigger == null) {
                    var orderVar = 0;
                    if (order == -1) {
                        orderVar = self.contentLength - 1 - self.itemsOnScreen;
                    }
                    index = (self.activeItem + orderVar) % (self.contentLength + 1 - self.itemsOnScreen);
                }
                else {
                    if (typeof(trigger) == "number") {
                        index = trigger;
                    }
                    else {
                        index = (parseInt($(trigger).attr('data-trigger')) * self.itemsOnScreen);
                    }
                }

                self.setActiveContent(index+1);

                var scroll = index * self.itemWidth;
                carouselContainer.stop().css({overflowX:'hidden', marginBottom: '0'}).animate({
                    scrollLeft: scroll
                }, time, function() {
                    $(this).css({overflowX:'scroll', marginBottom: '-15px'});
                });
            };

            self.setActiveContent = function(index) {
                carouselContainer.find('.fat-carousel-item').removeClass('fat-carousel-active');
                carouselContainer.find('[data-order=' + index + ']').addClass('fat-carousel-active');

                self.activeItem = index;

                self.setNavigationActive();
            };

            /* -------------------- SCROLLSTOP -------------------- */

            self.addCarouselScrollStop = function() {
                carouselContainer.on('scrollstop', function() {
                    self.scrollStopAction();
                });
            };

            self.scrollStopAction = function() {
                clearInterval(self.slideAnimation);
                self.slideAnimation = "";
                self.slideAnimation = setInterval(function() { self.scrollToSlide(600); }, 5000);

                var scroll = carouselContainer.scrollLeft();
                var scrollIndex = scroll / self.itemWidth;
                if (Math.abs(scrollIndex - Math.round(scrollIndex)) > 0.01) {
                    var index = 0;
                    if (scrollIndex - Math.floor(scrollIndex) < .5) {
                        index = Math.floor(scroll / self.itemWidth);
                    }
                    else {
                        index = Math.ceil(scroll / self.itemWidth);
                    }
                    self.scrollToSlide(300, index);
                }
                else {
                    self.setActiveContent(Math.round(scrollIndex)+1);
                }
            };

            /* -------------------- WINDOW RESIZE -------------------- */

            self.addResizeControl = function() {
                var windowResizeTimer;
                $(window).on('resize', function() {
                    clearTimeout(windowResizeTimer);
                    windowResizeTimer = setTimeout(function() {
                        self.setPreferences();

                        var index = self.activeItem;
                        self.scrollToSlide(10, index-1);
                    }, 100);
                });
            };

            self.initialize();

        });
    }
});